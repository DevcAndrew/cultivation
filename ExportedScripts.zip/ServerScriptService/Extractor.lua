local exportFolder = "ExtractedScripts"

-- Compatibility layer
local isfolder = isfolder or function(path)
	local ok = pcall(function() listfiles(path) end)
	return ok
end

local makefolder = makefolder or createdir or function(path)
	-- fallback: some executors auto-create on writefile
end

local writefile = writefile or savefile

local function createFolder(path)
	if not isfolder(path) then
		makefolder(path)
	end
end

createFolder(exportFolder)

for _, obj in ipairs(game:GetDescendants()) do
	if obj:IsA("Script") or obj:IsA("LocalScript") or obj:IsA("ModuleScript") then
		local success, source = pcall(function() return obj.Source end)
		if success and source then
			local path = exportFolder .. "/" .. obj:GetFullName():gsub("%.", "/")
			local folderPath = path:match("(.+)/[^/]+$")
			if folderPath then
				createFolder(folderPath)
			end
			pcall(writefile, path .. ".lua", source)
		end
	end
end

print("All scripts exported.")