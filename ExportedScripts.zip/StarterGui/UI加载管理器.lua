-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled with Velocity Script Decompiler
local v1 = game:GetService("Players")
UI_E5_8A_A0_E8_BD_BD_E7_AE_A1_E7_90_86_E5_99_A8 = {}
_E5_BC_95_E7_94_A8_E7_AE_A1_E7_90_86_E5_99_A8 = {}
local v2 = require((game:GetService("ReplicatedStorage"):WaitForChild("BaseState", 60)))
require((game:GetService("ReplicatedStorage"):WaitForChild("FsmMachine", 60)))
local v3 = v2:New("\233\187\152\232\174\164\231\138\182\230\128\129")
function v3.OnEnter(_) end
function v3.OnUpdate(_) end
function v3.OnLeave(_) end
local v4 = game:GetService("ReplicatedStorage")
_E5_B8_B8_E9_87_8F = require((v4:WaitForChild("\232\132\154\230\156\172\230\168\161\229\157\151", 5):WaitForChild("\229\133\172\231\148\168", 5):WaitForChild("\229\188\149\231\148\168\231\174\161\231\144\134\229\153\168", 5)))["\232\142\183\229\143\150\230\168\161\229\157\151\229\188\149\231\148\168"]("\229\184\184\233\135\143")
local v5 = v1.LocalPlayer:WaitForChild("PlayerGui", 120):WaitForChild("GUI", 120)
for _, v6 in ipairs(v5:GetDescendants()) do
    if v6:isA("ModuleScript") then
        require(v6)
    end
end
return UI_E5_8A_A0_E8_BD_BD_E7_AE_A1_E7_90_86_E5_99_A8