-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled with Velocity Script Decompiler
local v1 = game:GetService("UserInputService")
local v2 = game:GetService("RunService")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game:GetService("Players")
_E6_8A_80_E8_83_BDUI = {}
_E5_BC_95_E7_94_A8_E7_AE_A1_E7_90_86_E5_99_A8 = {}
UI_E5_9F_BA_E7_A1_80_E5_B7_A5_E5_85_B7 = {}
_E5_AE_A2_E6_88_B7_E7_AB_AF_E6_8A_80_E8_83_BD_E4_BD_BF_E7_94_A8_E7_AE_A1_E7_90_86_E5_99_A8 = {}
_E6_95_B0_E5_AD_A6_E8_BF_90_E7_AE_97 = {}
_E5_8A_A8_E7_94_BB_E5_B1_9E_E6_80_A7 = {}
_E5_B8_B8_E9_87_8F = {}
_E6_8A_80_E8_83_BD_E5_B7_A5_E5_85_B7 = {}
local v5 = require((game:GetService("ReplicatedStorage"):WaitForChild("BaseState", 60)))
require((game:GetService("ReplicatedStorage"):WaitForChild("FsmMachine", 60)))
local v6 = v5:New("\233\187\152\232\174\164\231\138\182\230\128\129")
function create_list_repeated(p7, p8)
    local v9 = {}
    for _ = 1, p8 do
        table.insert(v9, p7)
    end
    return v9
end
function _E4_BD_BF_E7_94_A8_E8_81_8C_E4_B8_9A_E6_8A_80_E8_83_BD(p10)
    if _E6_8A_80_E8_83_BD_E6_81_A2_E5_A4_8D_E6_97_B6_E9_97_B4_E5_88_97_E8_A1_A8[1] == 0 then
        local v11 = _E8_81_8C_E4_B8_9A_E6_8A_80_E8_83_BD_E8_A1_A8_E6_95_B0_E6_8D_AE()
        _E5_AE_A2_E6_88_B7_E7_AB_AF_E6_8A_80_E8_83_BD_E4_BD_BF_E7_94_A8_E7_AE_A1_E7_90_86_E5_99_A8["\229\176\157\232\175\149\228\189\191\231\148\168\230\138\128\232\131\189"](1, v11, p10, true)
    end
end
function _E4_BD_BF_E7_94_A8_E6_8A_80_E8_83_BD(p12, p13)
    if _E6_8A_80_E8_83_BD_E6_81_A2_E5_A4_8D_E6_97_B6_E9_97_B4_E5_88_97_E8_A1_A8[p12 + 1] ~= 0 then
        return nil
    end
    if not _E7_8E_A9_E5_AE_B6_E6_8A_80_E8_83_BD_E6_95_B0_E6_8D_AE then
        return nil
    end
    local v14 = _E7_8E_A9_E5_AE_B6_E6_8A_80_E8_83_BD_E6_95_B0_E6_8D_AE["\232\163\133\229\164\135\228\184\173"][p12]
    if not v14 then
        return nil
    end
    local v15 = _E7_8E_A9_E5_AE_B6_E6_8A_80_E8_83_BD_E6_95_B0_E6_8D_AE["\232\131\140\229\140\133"][v14]
    local v16 = _E6_8A_80_E8_83_BD_E8_A1_A8[v15.ID]
    _E5_AE_A2_E6_88_B7_E7_AB_AF_E6_8A_80_E8_83_BD_E4_BD_BF_E7_94_A8_E7_AE_A1_E7_90_86_E5_99_A8["\229\176\157\232\175\149\228\189\191\231\148\168\230\138\128\232\131\189"](p12, v16, p13)
    return true
end
function _E5_88_87_E6_8D_A2_E8_87_AA_E5_8A_A8_E4_BD_BF_E7_94_A8()
    _E7_8E_A9_E5_AE_B6_E4_BF_AE_E6_94_B9_E8_AE_BE_E7_BD_AE_E4_BA_8B_E4_BB_B6:FireServer("\232\135\170\229\138\168\230\138\128\232\131\189")
end
function _E6_8A_80_E8_83_BD_E5_86_B7_E5_8D_B4UI_E6_9B_B4_E6_96_B0()
    for v17, v18 in ipairs(_E6_8A_80_E8_83_BD_E6_81_A2_E5_A4_8D_E6_97_B6_E9_97_B4_E5_88_97_E8_A1_A8) do
        local v19 = _E6_8A_80_E8_83_BD_E5_86_B7_E5_8D_B4_E6_97_B6_E9_97_B4_E5_88_97_E8_A1_A8[v17]
        if v18 ~= 0 then
            local v20 = _E6_8A_80_E8_83_BDCD_E6_96_87_E6_9C_AC_E5_88_97_E8_A1_A8[v17]
            local v21 = v18 - workspace:GetServerTimeNow()
            local v22 = v21 / v19
            local v23 = v22 > 1 and 1 or v22
            v20.Text = _E6_95_B0_E5_AD_A6_E8_BF_90_E7_AE_97["\228\191\157\231\149\153\229\176\143\230\149\176"](v21, 1) .. "s"
            if v23 < 0 then
                _E6_8A_80_E8_83_BD_E6_81_A2_E5_A4_8D_E6_97_B6_E9_97_B4_E5_88_97_E8_A1_A8[v17] = 0
                _E6_8A_80_E8_83_BD_E6_81_A2_E5_A4_8D_E5_8A_A8_E7_94_BB(v17)
                v20.Text = ""
                v23 = 0
            end
            _E6_8A_80_E8_83_BD_E9_81_AE_E7_BD_A9UI_E5_88_97_E8_A1_A8[v17].Size = UDim2.new(1, -6, v23, 0)
        end
    end
end
function _E8_87_AA_E5_8A_A8_E4_BD_BF_E7_94_A8_E6_8A_80_E8_83_BD2()
    if _E8_87_AA_E5_8A_A8_E4_BD_BF_E7_94_A8_E6_8A_80_E8_83_BD then
        _E4_BD_BF_E7_94_A8_E8_81_8C_E4_B8_9A_E6_8A_80_E8_83_BD(true)
        if _E4_BD_BF_E7_94_A8_E6_8A_80_E8_83_BD(1, true) then
            return
        end
        if _E4_BD_BF_E7_94_A8_E6_8A_80_E8_83_BD(2, true) then
            return
        end
        if _E4_BD_BF_E7_94_A8_E6_8A_80_E8_83_BD(3, true) then
            return
        end
    end
end
function _E6_9B_B4_E6_96_B0_E8_87_AA_E5_8A_A8_E6_8A_80_E8_83_BD_E6_8C_89_E9_92_AE()
    if _E8_87_AA_E5_8A_A8_E4_BD_BF_E7_94_A8_E6_8A_80_E8_83_BD then
        _E8_87_AA_E5_8A_A8_E6_8A_80_E8_83_BD_E6_96_87_E6_9C_AC.TextColor3 = Color3.fromRGB(0, 255, 0)
        _E8_87_AA_E5_8A_A8_E6_8A_80_E8_83_BD_E6_8C_89_E9_92_AE_E5_8A_A8_E7_94_BB:Play()
        _E8_87_AA_E5_8A_A8_E6_8A_80_E8_83_BD_E6_8F_8F_E8_BE_B9.Enabled = true
    else
        _E8_87_AA_E5_8A_A8_E6_8A_80_E8_83_BD_E6_96_87_E6_9C_AC.TextColor3 = Color3.fromRGB(255, 255, 255)
        _E8_87_AA_E5_8A_A8_E6_8A_80_E8_83_BD_E6_8C_89_E9_92_AE_E5_8A_A8_E7_94_BB:Pause()
        _E8_87_AA_E5_8A_A8_E6_8A_80_E8_83_BD_E6_8F_8F_E8_BE_B9.Enabled = false
    end
end
function _E6_8A_80_E8_83_BD_E6_81_A2_E5_A4_8D_E5_8A_A8_E7_94_BB(p24)
    -- upvalues: (copy) v_u_3
    local v25
    if p24 == 1 then
        v25 = _E8_81_8C_E4_B8_9A_E6_8A_80_E8_83_BDUI
    else
        v25 = _E6_8A_80_E8_83_BDUI_E5_88_97_E8_A1_A8[p24 - 1]
    end
    v25.Size = UDim2.new(1, 0, 1, 0)
    local v26 = {
        ["Size"] = UDim2.new(1.2, 0, 1.2, 0)
    }
    v_u_3:Create(v25, TweenInfo.new(0.15, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, true, 0), v26):Play()
end
function _E6_9B_B4_E6_96_B0_E8_81_8C_E4_B8_9A_E6_8A_80_E8_83_BD_E6_98_BE_E7_A4_BA()
    local v27 = _E8_81_8C_E4_B8_9A_E6_8A_80_E8_83_BD_E8_A1_A8_E6_95_B0_E6_8D_AE()
    local v28 = _E8_81_8C_E4_B8_9A_E6_8A_80_E8_83_BDUI:FindFirstChild("\229\155\190\231\137\135\230\161\134", false)
    local v29 = v28:WaitForChild("UIGradient", 5)
    v28:FindFirstChild("\229\155\190\230\160\135", false).Image = v27["\229\155\190\230\160\135"]
    v29.Color = _E5_B8_B8_E9_87_8F["\233\128\154\231\148\168\229\147\129\232\180\168\229\175\185\229\186\148\230\184\144\229\143\152\233\162\156\232\137\178"](v27["\229\147\129\232\180\168"])
    _E6_8A_80_E8_83_BD_E5_86_B7_E5_8D_B4_E6_97_B6_E9_97_B4_E5_88_97_E8_A1_A8[1] = v27["\229\134\183\229\141\180\230\151\182\233\151\180"]
end
function _E8_81_8C_E4_B8_9A_E6_8A_80_E8_83_BD_E8_A1_A8_E6_95_B0_E6_8D_AE()
    local v30 = _E8_81_8C_E4_B8_9A_E8_A1_A8[_E7_8E_A9_E5_AE_B6_E7_AD_89_E7_BA_A7_E6_95_B0_E6_8D_AE["\232\129\140\228\184\154"]]
    local v31 = _E6_8A_80_E8_83_BD_E8_A1_A8
    local v32 = v30["\230\138\128\232\131\189ID"]
    return v31[tostring(v32)]
end
function _E8_87_AA_E5_8A_A8_E6_8A_80_E8_83_BD_E5_8A_A8_E7_94_BB()
    -- upvalues: (copy) v_u_3
    local v33 = TweenInfo.new(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, -1, false, 0)
    _E8_87_AA_E5_8A_A8_E6_8A_80_E8_83_BD_E6_8C_89_E9_92_AE_E5_8A_A8_E7_94_BB = v_u_3:Create(_E8_87_AA_E5_8A_A8_E6_8A_80_E8_83_BD_E6_8F_8F_E8_BE_B9, v33, {
        ["Rotation"] = 360
    })
end
function _E9_9A_90_E8_97_8F_E9_BB_98_E8_AE_A4_E8_B7_B3_E8_B7_83_E6_8C_89_E9_92_AE()
    -- upvalues: (copy) v_u_4
    task.spawn(function()
        -- upvalues: (ref) v_u_4
        local v34 = v_u_4.LocalPlayer:WaitForChild("PlayerGui", 120):WaitForChild("TouchGui", 15)
        if v34 then
            local v35 = v34:WaitForChild("TouchControlFrame", 15)
            local v_u_36 = v35 and v35:WaitForChild("JumpButton", 15)
            if v_u_36 then
                v_u_36.Visible = false
                v_u_36:GetPropertyChangedSignal("Visible"):Connect(function()
                    -- upvalues: (copy) v_u_36
                    if v_u_36.Visible then
                        v_u_36.Visible = false
                    end
                end)
            end
        end
    end)
end
function _E6_9B_B4_E6_96_B0_E6_99_AE_E9_80_9A_E6_8A_80_E8_83_BD_E6_98_BE_E7_A4_BA()
    for v37, v38 in ipairs(_E6_8A_80_E8_83_BDUI_E5_88_97_E8_A1_A8) do
        local v39 = _E7_8E_A9_E5_AE_B6_E6_8A_80_E8_83_BD_E6_95_B0_E6_8D_AE["\232\163\133\229\164\135\228\184\173"][v37]
        local v40 = v38:FindFirstChild("\229\155\190\231\137\135\230\161\134", false)
        local v41 = v40:WaitForChild("UIGradient", 5)
        local v42 = v40:FindFirstChild("\229\155\190\230\160\135", false)
        local v43 = v38:FindFirstChild("\230\143\144\231\164\186", false)
        local v44 = v38:FindFirstChild("\229\134\133\229\156\136\232\131\140\230\153\175", false):FindFirstChild("UIStroke"):FindFirstChild("\233\171\152\231\186\167\230\184\144\229\143\152", false)
        if v39 then
            local v45 = _E7_8E_A9_E5_AE_B6_E6_8A_80_E8_83_BD_E6_95_B0_E6_8D_AE["\232\131\140\229\140\133"][v39]
            local v46 = _E6_8A_80_E8_83_BD_E8_A1_A8[v45.ID]
            _E6_8A_80_E8_83_BD_E5_86_B7_E5_8D_B4_E6_97_B6_E9_97_B4_E5_88_97_E8_A1_A8[v37 + 1] = v46["\229\134\183\229\141\180\230\151\182\233\151\180"]
            v42.Image = v46["\229\155\190\230\160\135"]
            v42.Size = UDim2.new(1, 0, 1, 0)
            if v43 then
                v43.Visible = true
            end
            v41.Color = _E5_B8_B8_E9_87_8F["\233\128\154\231\148\168\229\147\129\232\180\168\229\175\185\229\186\148\230\184\144\229\143\152\233\162\156\232\137\178"](v46["\229\147\129\232\180\168"])
            v40.BackgroundTransparency = 0
            if v46["\229\147\129\232\180\168"] >= _E5_B8_B8_E9_87_8F["\233\171\152\231\186\167\229\147\129\232\180\168"] then
                v44.Enabled = true
            else
                v44.Enabled = false
            end
        else
            v44.Enabled = false
            if _E6_8A_80_E8_83_BD_E5_B7_A5_E5_85_B7["\230\138\128\232\131\189\230\167\189\230\152\175\229\144\166\232\167\163\233\148\129"](v37) then
                v42.Image = ""
            else
                v42.Size = UDim2.new(0.7, 0, 0.7, 0)
                v42.Image = "rbxassetid://11492669942"
            end
            if v43 then
                v43.Visible = false
            end
            v40.BackgroundTransparency = 1
        end
    end
end
function v6.OnEnter(_) end
function v6.OnUpdate(_) end
function v6.OnLeave(_)
    event_customEvent_onFire_1:Disconnect()
    event_gui_Button_activated_2:Disconnect()
    event_runserver_stepped_3:Disconnect()
    event_customEvent_onClientEvent_4:Disconnect()
    event_customEvent_onClientEvent_5:Disconnect()
    event_customEvent_onClientEvent_6:Disconnect()
    event_inputEnded_7:Disconnect()
end
_E6_8A_80_E8_83_BD_E5_86_B7_E5_8D_B4_E6_97_B6_E9_97_B4_E5_88_97_E8_A1_A8 = create_list_repeated(0, 4)
_E6_8A_80_E8_83_BD_E6_81_A2_E5_A4_8D_E6_97_B6_E9_97_B4_E5_88_97_E8_A1_A8 = create_list_repeated(1, 4)
_E6_98_AF_E5_90_A6_E6_9C_89_E6_89_8B_E6_9F_84 = game:GetService("UserInputService").GamepadEnabled
_E4_B8_BB_E7_95_8C_E9_9D_A2 = script.Parent
if v1.TouchEnabled then
    _E6_8A_80_E8_83_BD_E5_8C_BA_E5_9F_9F = _E4_B8_BB_E7_95_8C_E9_9D_A2:WaitForChild("\232\167\166\230\145\184", 5)
    _E9_9A_90_E8_97_8F_E9_BB_98_E8_AE_A4_E8_B7_B3_E8_B7_83_E6_8C_89_E9_92_AE()
    local v_u_47 = false
    local v48 = _E6_8A_80_E8_83_BD_E5_8C_BA_E5_9F_9F:WaitForChild("\232\183\179\232\183\131\230\140\137\233\146\174", 5):WaitForChild("\230\140\137\233\146\174", 5)
    local v_u_49 = nil
    v48.InputBegan:Connect(function(p50)
        -- upvalues: (ref) v_u_47, (ref) v_u_49
        v_u_47 = true
        v_u_49 = p50
    end)
    v48.InputEnded:Connect(function(p51)
        -- upvalues: (ref) v_u_49, (ref) v_u_47
        if v_u_49 == p51 then
            v_u_49 = nil
            v_u_47 = false
        end
    end)
    v2.RenderStepped:Connect(function(_)
        -- upvalues: (ref) v_u_47
        if _E5_AE_A2_E6_88_B7_E7_AB_AF_E8_A7_92_E8_89_B2_E7_AE_A1_E7_90_86_E5_99_A8["\228\186\186\229\189\162\231\148\159\231\137\169"] then
            _E5_AE_A2_E6_88_B7_E7_AB_AF_E8_A7_92_E8_89_B2_E7_AE_A1_E7_90_86_E5_99_A8["\228\186\186\229\189\162\231\148\159\231\137\169"].Jump = v_u_47
        end
    end)
else
    _E6_8A_80_E8_83_BD_E5_8C_BA_E5_9F_9F = _E4_B8_BB_E7_95_8C_E9_9D_A2:WaitForChild("\230\140\137\233\148\174", 5)
end
_E8_87_AA_E5_8A_A8_E6_8A_80_E8_83_BD_E6_8C_89_E9_92_AE = _E6_8A_80_E8_83_BD_E5_8C_BA_E5_9F_9F:WaitForChild("\230\138\128\232\131\189\232\135\170\229\138\168", 5):WaitForChild("\230\140\137\233\146\174", 5)
_E8_87_AA_E5_8A_A8_E6_8A_80_E8_83_BD_E6_96_87_E6_9C_AC = _E8_87_AA_E5_8A_A8_E6_8A_80_E8_83_BD_E6_8C_89_E9_92_AE:WaitForChild("\230\150\135\230\156\172", 5)
_E8_87_AA_E5_8A_A8_E6_8A_80_E8_83_BD_E6_8F_8F_E8_BE_B9 = _E8_87_AA_E5_8A_A8_E6_8A_80_E8_83_BD_E6_8C_89_E9_92_AE:WaitForChild("\229\134\133\229\156\136\232\131\140\230\153\175", 5):WaitForChild("UIStroke", 5):WaitForChild("\229\189\169\232\137\178\230\143\143\232\190\185", 5)
_E6_8A_80_E8_83_BD_E5_8C_BA_E5_9F_9F.Visible = true
local v52 = game:GetService("ReplicatedStorage")
local v_u_53 = require((v52:WaitForChild("\232\132\154\230\156\172\230\168\161\229\157\151", 5):WaitForChild("\229\133\172\231\148\168", 5):WaitForChild("\229\188\149\231\148\168\231\174\161\231\144\134\229\153\168", 5)))
_E5_AE_A2_E6_88_B7_E7_AB_AF_E8_A7_92_E8_89_B2_E7_AE_A1_E7_90_86_E5_99_A8 = v_u_53["\232\142\183\229\143\150\230\168\161\229\157\151\229\188\149\231\148\168"]("\229\174\162\230\136\183\231\171\175\232\167\146\232\137\178\231\174\161\231\144\134\229\153\168")
_E6_8A_80_E8_83_BD_E5_B7_A5_E5_85_B7 = v_u_53["\232\142\183\229\143\150\230\168\161\229\157\151\229\188\149\231\148\168"]("\230\138\128\232\131\189\229\183\165\229\133\183")
_E5_90_8C_E6_AD_A5_E6_8A_80_E8_83_BD_E6_95_B0_E6_8D_AE_E4_BA_8B_E4_BB_B6 = v_u_53["\232\142\183\229\143\150\228\186\139\228\187\182\229\188\149\231\148\168"]("\230\138\128\232\131\189", "\229\144\140\230\173\165\230\138\128\232\131\189\230\149\176\230\141\174")
_E5_90_8C_E6_AD_A5_E7_AD_89_E7_BA_A7_E6_95_B0_E6_8D_AE_E4_BA_8B_E4_BB_B6 = v_u_53["\232\142\183\229\143\150\228\186\139\228\187\182\229\188\149\231\148\168"]("\231\173\137\231\186\167", "\229\144\140\230\173\165\231\173\137\231\186\167\230\149\176\230\141\174")
_E6_8A_80_E8_83_BD_E8_BF_9B_E5_85_A5_E5_86_B7_E5_8D_B4_E4_BA_8B_E4_BB_B6 = v_u_53["\232\142\183\229\143\150\228\186\139\228\187\182\229\188\149\231\148\168"]("\230\138\128\232\131\189", "\230\138\128\232\131\189\232\191\155\229\133\165\229\134\183\229\141\180")
_E5_AE_A2_E6_88_B7_E7_AB_AF_E6_8A_80_E8_83_BD_E4_BD_BF_E7_94_A8_E7_AE_A1_E7_90_86_E5_99_A8 = v_u_53["\232\142\183\229\143\150\230\168\161\229\157\151\229\188\149\231\148\168"]("\229\174\162\230\136\183\231\171\175\230\138\128\232\131\189\228\189\191\231\148\168\231\174\161\231\144\134\229\153\168")
_E5_B8_B8_E9_87_8F = v_u_53["\232\142\183\229\143\150\230\168\161\229\157\151\229\188\149\231\148\168"]("\229\184\184\233\135\143")
UI_E5_9F_BA_E7_A1_80_E5_B7_A5_E5_85_B7 = v_u_53["\232\142\183\229\143\150\230\168\161\229\157\151\229\188\149\231\148\168"]("UI\229\159\186\231\161\128\229\183\165\229\133\183")
_E6_95_B0_E5_AD_A6_E8_BF_90_E7_AE_97 = v_u_53["\232\142\183\229\143\150\230\168\161\229\157\151\229\188\149\231\148\168"]("\230\149\176\229\173\166\232\191\144\231\174\151")
_E6_98_BE_E7_A4_BA_E6_96_87_E5_AD_97_E4_BA_8B_E4_BB_B6 = v_u_53["\232\142\183\229\143\150\228\186\139\228\187\182\229\188\149\231\148\168"]("\229\174\162\230\136\183\231\171\175UI", "\230\152\190\231\164\186\230\150\135\229\173\151\230\143\144\231\164\186")
_E6_8A_80_E8_83_BD_E8_A1_A8 = v_u_53["\232\142\183\229\143\150\230\149\176\230\141\174\232\161\168"]("\230\138\128\232\131\189\232\161\168")
_E8_81_8C_E4_B8_9A_E8_A1_A8 = v_u_53["\232\142\183\229\143\150\230\149\176\230\141\174\232\161\168"]("\232\129\140\228\184\154\232\161\168")
_E7_8E_A9_E5_AE_B6_E5_80_BC_E5_AF_B9_E8_B1_A1_E8_8E_B7_E5_8F_96_E5_AE_8C_E6_88_90_E4_BA_8B_E4_BB_B6 = v_u_53["\232\142\183\229\143\150\228\186\139\228\187\182\229\188\149\231\148\168"]("\229\174\162\230\136\183\231\171\175\229\136\157\229\167\139\229\140\150", "\231\142\169\229\174\182\229\128\188\229\175\185\232\177\161\232\142\183\229\143\150\229\174\140\230\136\144")
_E7_8E_A9_E5_AE_B6_E4_BF_AE_E6_94_B9_E8_AE_BE_E7_BD_AE_E4_BA_8B_E4_BB_B6 = v_u_53["\232\142\183\229\143\150\228\186\139\228\187\182\229\188\149\231\148\168"]("\232\174\190\231\189\174", "\231\142\169\229\174\182\228\191\174\230\148\185\232\174\190\231\189\174")
_E5_AE_A2_E6_88_B7_E7_AB_AF_E5_88_9B_E5_BB_BA_E7_B2_92_E5_AD_90_E4_BA_8B_E4_BB_B6 = v_u_53["\232\142\183\229\143\150\228\186\139\228\187\182\229\188\149\231\148\168"]("\229\174\162\230\136\183\231\171\175\231\137\185\230\149\136", "\229\174\162\230\136\183\231\171\175\229\136\155\229\187\186\231\178\146\229\173\144")
_E6_8A_80_E8_83_BDUI_E5_88_97_E8_A1_A8 = {}
_E6_8A_80_E8_83_BD_E9_81_AE_E7_BD_A9UI_E5_88_97_E8_A1_A8 = {}
_E6_8A_80_E8_83_BDCD_E6_96_87_E6_9C_AC_E5_88_97_E8_A1_A8 = {}
for _, v54 in ipairs(_E6_8A_80_E8_83_BD_E5_8C_BA_E5_9F_9F:GetChildren()) do
    local v_u_55 = v54:GetAttribute("id")
    if v_u_55 then
        local v56 = v54:FindFirstChild("\230\140\137\233\146\174", false)
        local v57 = v56:FindFirstChild("\229\134\133\229\156\136\232\131\140\230\153\175", false)
        local v58 = v56:FindFirstChild("\233\129\174\231\189\169", false)
        local v59 = v58:FindFirstChild("\233\129\174\231\189\169\229\134\133\229\177\130", false)
        local v60 = v56:FindFirstChild("\229\128\146\232\174\161\230\151\182", false)
        UI_E5_9F_BA_E7_A1_80_E5_B7_A5_E5_85_B7["\232\191\155\229\186\166\230\157\161\229\137\141\230\153\175\231\187\145\229\174\154\229\164\167\229\176\143"](v59, v57, true)
        if v_u_55 == 1 then
            _E8_81_8C_E4_B8_9A_E6_8A_80_E8_83_BDUI = v56
            v56.Activated:Connect(function(_, _)
                _E4_BD_BF_E7_94_A8_E8_81_8C_E4_B8_9A_E6_8A_80_E8_83_BD(nil)
            end)
        else
            v56.Activated:Connect(function(_, _)
                -- upvalues: (copy) v_u_55
                _E4_BD_BF_E7_94_A8_E6_8A_80_E8_83_BD(v_u_55 - 1, nil)
            end)
            _E6_8A_80_E8_83_BDUI_E5_88_97_E8_A1_A8[v_u_55 - 1] = v56
        end
        _E6_8A_80_E8_83_BD_E9_81_AE_E7_BD_A9UI_E5_88_97_E8_A1_A8[v_u_55] = v58
        _E6_8A_80_E8_83_BDCD_E6_96_87_E6_9C_AC_E5_88_97_E8_A1_A8[v_u_55] = v60
    end
end
_E8_87_AA_E5_8A_A8_E6_8A_80_E8_83_BD_E5_8A_A8_E7_94_BB()
_E6_9B_B4_E6_96_B0_E8_87_AA_E5_8A_A8_E6_8A_80_E8_83_BD_E6_8C_89_E9_92_AE()
event_runserver_stepped_3 = v2.Stepped:Connect(function(_, _)
    if not _E7_8E_A9_E5_AE_B6_E7_AD_89_E7_BA_A7_E6_95_B0_E6_8D_AE then
        return nil
    end
    _E6_8A_80_E8_83_BD_E5_86_B7_E5_8D_B4UI_E6_9B_B4_E6_96_B0()
    _E8_87_AA_E5_8A_A8_E4_BD_BF_E7_94_A8_E6_8A_80_E8_83_BD2()
end)
event_inputEnded_7 = v1.InputEnded:Connect(function(p61, p62)
    if not _E7_8E_A9_E5_AE_B6_E6_8A_80_E8_83_BD_E6_95_B0_E6_8D_AE then
        return nil
    end
    if p62 then
        return nil
    end
    local v63 = p61.KeyCode.Value
    if v63 == 49 or v63 == 1006 then
        _E4_BD_BF_E7_94_A8_E8_81_8C_E4_B8_9A_E6_8A_80_E8_83_BD(nil)
    end
    if v63 == 1000 then
        _E4_BD_BF_E7_94_A8_E6_8A_80_E8_83_BD(1, nil)
    end
    if v63 == 1001 then
        _E4_BD_BF_E7_94_A8_E6_8A_80_E8_83_BD(2, nil)
    end
    if v63 == 1003 then
        _E4_BD_BF_E7_94_A8_E6_8A_80_E8_83_BD(3, nil)
    end
    if v63 >= 50 and v63 <= 52 then
        _E4_BD_BF_E7_94_A8_E6_8A_80_E8_83_BD(v63 - 49, nil)
    end
    if v63 == 113 or v63 == 1007 then
        _E5_88_87_E6_8D_A2_E8_87_AA_E5_8A_A8_E4_BD_BF_E7_94_A8()
    end
end)
event_customEvent_onFire_1 = _E7_8E_A9_E5_AE_B6_E5_80_BC_E5_AF_B9_E8_B1_A1_E8_8E_B7_E5_8F_96_E5_AE_8C_E6_88_90_E4_BA_8B_E4_BB_B6.Event:Connect(function(_, _, _)
    -- upvalues: (copy) v_u_53
    local v64 = v_u_53["\232\142\183\229\143\150\231\142\169\229\174\182\229\128\188\229\175\185\232\177\161"]("\232\174\190\231\189\174", "\232\135\170\229\138\168\230\138\128\232\131\189")
    _E8_87_AA_E5_8A_A8_E4_BD_BF_E7_94_A8_E6_8A_80_E8_83_BD = v64.Value
    _E6_9B_B4_E6_96_B0_E8_87_AA_E5_8A_A8_E6_8A_80_E8_83_BD_E6_8C_89_E9_92_AE()
    v64.Changed:Connect(function(p65)
        _E8_87_AA_E5_8A_A8_E4_BD_BF_E7_94_A8_E6_8A_80_E8_83_BD = p65
        _E6_9B_B4_E6_96_B0_E8_87_AA_E5_8A_A8_E6_8A_80_E8_83_BD_E6_8C_89_E9_92_AE()
    end)
end)
event_gui_Button_activated_2 = _E8_87_AA_E5_8A_A8_E6_8A_80_E8_83_BD_E6_8C_89_E9_92_AE.Activated:Connect(function(_, _)
    _E5_88_87_E6_8D_A2_E8_87_AA_E5_8A_A8_E4_BD_BF_E7_94_A8()
end)
event_customEvent_onClientEvent_4 = _E5_90_8C_E6_AD_A5_E6_8A_80_E8_83_BD_E6_95_B0_E6_8D_AE_E4_BA_8B_E4_BB_B6.OnClientEvent:Connect(function(p66, _, _)
    _E7_8E_A9_E5_AE_B6_E6_8A_80_E8_83_BD_E6_95_B0_E6_8D_AE = p66
    _E6_9B_B4_E6_96_B0_E6_99_AE_E9_80_9A_E6_8A_80_E8_83_BD_E6_98_BE_E7_A4_BA()
end)
event_customEvent_onClientEvent_5 = _E6_8A_80_E8_83_BD_E8_BF_9B_E5_85_A5_E5_86_B7_E5_8D_B4_E4_BA_8B_E4_BB_B6.OnClientEvent:Connect(function(p67, p68, _)
    _E6_8A_80_E8_83_BD_E6_81_A2_E5_A4_8D_E6_97_B6_E9_97_B4_E5_88_97_E8_A1_A8[p67] = p68
end)
event_customEvent_onClientEvent_6 = _E5_90_8C_E6_AD_A5_E7_AD_89_E7_BA_A7_E6_95_B0_E6_8D_AE_E4_BA_8B_E4_BB_B6.OnClientEvent:Connect(function(p69, _, _)
    _E7_8E_A9_E5_AE_B6_E7_AD_89_E7_BA_A7_E6_95_B0_E6_8D_AE = p69
    _E6_9B_B4_E6_96_B0_E8_81_8C_E4_B8_9A_E6_8A_80_E8_83_BD_E6_98_BE_E7_A4_BA()
end)
return _E6_8A_80_E8_83_BDUI