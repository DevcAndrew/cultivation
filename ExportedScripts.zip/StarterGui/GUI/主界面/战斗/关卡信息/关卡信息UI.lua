-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled with Velocity Script Decompiler
local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
_E5_85_B3_E5_8D_A1_E4_BF_A1_E6_81_AFUI = {}
_E5_BC_95_E7_94_A8_E7_AE_A1_E7_90_86_E5_99_A8 = {}
_E6_97_B6_E9_97_B4_E6_A8_A1_E5_9D_97 = {}
local v3 = require((game:GetService("ReplicatedStorage"):WaitForChild("BaseState", 60)))
require((game:GetService("ReplicatedStorage"):WaitForChild("FsmMachine", 60)))
local v4 = v3:New("\233\187\152\232\174\164\231\138\182\230\128\129")
function v4.OnEnter(_) end
function v4.OnUpdate(_) end
function v4.OnLeave(_)
    event_customEvent_onClientEvent_1:Disconnect()
end
_E4_B8_BB_E7_95_8C_E9_9D_A2 = script.Parent
_E6_96_87_E6_9C_AC = _E4_B8_BB_E7_95_8C_E9_9D_A2:WaitForChild("\230\150\135\230\156\172", 5)
local v5 = game:GetService("ReplicatedStorage")
_E5_BC_95_E7_94_A8_E7_AE_A1_E7_90_86_E5_99_A8 = require((v5:WaitForChild("\232\132\154\230\156\172\230\168\161\229\157\151", 5):WaitForChild("\229\133\172\231\148\168", 5):WaitForChild("\229\188\149\231\148\168\231\174\161\231\144\134\229\153\168", 5)))
_E5_90_8C_E6_AD_A5_E6_89_80_E5_9C_A8_E5_85_B3_E5_8D_A1_E6_95_B0_E6_8D_AE_E4_BA_8B_E4_BB_B6 = _E5_BC_95_E7_94_A8_E7_AE_A1_E7_90_86_E5_99_A8["\232\142\183\229\143\150\228\186\139\228\187\182\229\188\149\231\148\168"]("\229\133\179\229\141\161", "\229\144\140\230\173\165\230\137\128\229\156\168\229\133\179\229\141\161\230\149\176\230\141\174")
_E6_97_B6_E9_97_B4_E6_A8_A1_E5_9D_97 = _E5_BC_95_E7_94_A8_E7_AE_A1_E7_90_86_E5_99_A8["\232\142\183\229\143\150\230\168\161\229\157\151\229\188\149\231\148\168"]("\230\151\182\233\151\180\230\168\161\229\157\151")
_E5_BC_80_E5_A7_8B_E6_97_B6_E9_97_B4 = workspace:GetServerTimeNow()
v_u_1.LocalPlayer:GetAttributeChangedSignal("Battle"):Connect(function()
    -- upvalues: (copy) v_u_1, (copy) v_u_2
    _E4_B8_BB_E7_95_8C_E9_9D_A2.Visible = v_u_1.LocalPlayer:GetAttribute("Battle")
    if v_u_1.LocalPlayer:GetAttribute("Battle") then
        if _E6_9B_B4_E6_96_B0_E5_80_92_E8_AE_A1_E6_97_B6 then
            _E6_9B_B4_E6_96_B0_E5_80_92_E8_AE_A1_E6_97_B6:Disconnect()
        end
        _E5_BC_80_E5_A7_8B_E6_97_B6_E9_97_B4 = workspace:GetServerTimeNow()
        _E6_9B_B4_E6_96_B0_E5_80_92_E8_AE_A1_E6_97_B6 = v_u_2.Stepped:Connect(function(_, _)
            -- upvalues: (ref) v_u_1
            _E6_96_87_E6_9C_AC.Text = _E5_85_B3_E5_8D_A1_E6_96_87_E6_9C_AC .. table.concat({ " [", _E6_97_B6_E9_97_B4_E6_A8_A1_E5_9D_97["\229\128\146\232\174\161\230\151\182\229\136\134\233\146\159"](workspace:GetServerTimeNow() - _E5_BC_80_E5_A7_8B_E6_97_B6_E9_97_B4), "]" })
            if not v_u_1.LocalPlayer:GetAttribute("Battle") then
                _E6_9B_B4_E6_96_B0_E5_80_92_E8_AE_A1_E6_97_B6:Disconnect()
                _E6_9B_B4_E6_96_B0_E5_80_92_E8_AE_A1_E6_97_B6 = nil
            end
        end)
    end
end)
event_customEvent_onClientEvent_1 = _E5_90_8C_E6_AD_A5_E6_89_80_E5_9C_A8_E5_85_B3_E5_8D_A1_E6_95_B0_E6_8D_AE_E4_BA_8B_E4_BB_B6.OnClientEvent:Connect(function(p6, _, _)
    _E5_85_B3_E5_8D_A1_E6_96_87_E6_9C_AC = p6
end)
return _E5_85_B3_E5_8D_A1_E4_BF_A1_E6_81_AFUI