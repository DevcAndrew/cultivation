-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled with Velocity Script Decompiler
_E8_AE_BE_E7_BD_AEUI_E7_AE_A1_E7_90_86_E5_99_A8 = {}
_E5_BC_95_E7_94_A8_E7_AE_A1_E7_90_86_E5_99_A8 = {}
UI_E5_8A_A8_E7_94_BB_E7_AE_A1_E7_90_86_E5_99_A8 = {}
local v1 = require((game:GetService("ReplicatedStorage"):WaitForChild("BaseState", 60)))
require((game:GetService("ReplicatedStorage"):WaitForChild("FsmMachine", 60)))
local v2 = v1:New("\233\187\152\232\174\164\231\138\182\230\128\129")
function _E6_9B_B4_E6_96_B0_E6_98_BE_E7_A4_BA()
    for v3, v4 in pairs(_E8_AE_BE_E7_BD_AE_E6_8C_89_E9_92_AE_E5_AF_B9_E8_B1_A1_E5_88_97_E8_A1_A8) do
        _E4_BF_AE_E6_94_B9_E5_BC_80_E5_85_B3_E7_8A_B6_E6_80_81(v4, _E7_8E_A9_E5_AE_B6_E8_AE_BE_E7_BD_AE_E6_95_B0_E6_8D_AE[v3])
    end
end
function _E6_9B_B4_E6_94_B9_E8_AE_BE_E7_BD_AE(p5)
    _E7_8E_A9_E5_AE_B6_E4_BF_AE_E6_94_B9_E8_AE_BE_E7_BD_AE_E4_BA_8B_E4_BB_B6:FireServer(p5)
end
function _E4_BF_AE_E6_94_B9_E5_BC_80_E5_85_B3_E7_8A_B6_E6_80_81(p6, p7)
    if p6:GetAttribute("multiple") then
        local v8 = p6:FindFirstChild("\233\128\137\233\161\185", false)
        for v9, v10 in ipairs(v8:GetChildren()) do
            v10.Visible = v9 == p7
        end
        return
    else
        local v11 = p6:FindFirstChild("\229\137\141\230\153\175", false)
        if p7 then
            v11.Visible = true
        else
            v11.Visible = false
        end
    end
end
function v2.OnEnter(_) end
function v2.OnUpdate(_) end
function v2.OnLeave(_)
    event_customEvent_onFire_1:Disconnect()
    event_gui_Button_activated_2:Disconnect()
    event_gui_Button_activated_3:Disconnect()
    event_customEvent_onFire_4:Disconnect()
    event_customEvent_onClientEvent_5:Disconnect()
    event_gui_Button_activated_6:Disconnect()
end
_E5_85_B3_E9_97_AD_E5_9B_9E_E8_B0_83_E4_BA_8B_E4_BB_B6 = Instance.new("BindableEvent")
_E4_B8_BB_E7_95_8C_E9_9D_A2 = script.Parent
_E8_83_8C_E6_99_AF = _E4_B8_BB_E7_95_8C_E9_9D_A2:WaitForChild("\232\131\140\230\153\175", 5)
_E5_85_B3_E9_97_AD_E6_8C_89_E9_92_AE = _E8_83_8C_E6_99_AF:WaitForChild("\229\133\179\233\151\173\230\140\137\233\146\174", 5):WaitForChild("\230\140\137\233\146\174", 5)
local v12 = _E8_83_8C_E6_99_AF:WaitForChild("\230\140\137\233\146\174", 5)
_E6_BF_80_E6_B4_BB_E7_A0_81_E6_8C_89_E9_92_AE = v12:WaitForChild("\230\191\128\230\180\187\231\160\129\230\140\137\233\146\174", 5):WaitForChild("\230\140\137\233\146\174", 5)
_E5_9B_9E_E5_9F_8E_E6_8C_89_E9_92_AE_E6_A1_86_E6_9E_B6 = v12:WaitForChild("\229\155\158\229\159\142\230\140\137\233\146\174", 5)
_E5_9B_9E_E5_9F_8E_E6_8C_89_E9_92_AE = _E5_9B_9E_E5_9F_8E_E6_8C_89_E9_92_AE_E6_A1_86_E6_9E_B6:WaitForChild("\230\140\137\233\146\174", 5)
local v13 = _E8_83_8C_E6_99_AF:WaitForChild("\232\174\190\231\189\174\229\140\186\229\159\159", 5)
_E8_AE_BE_E7_BD_AE_E6_8C_89_E9_92_AE_E5_AF_B9_E8_B1_A1_E5_88_97_E8_A1_A8 = {}
for _, v14 in ipairs(v13:GetDescendants()) do
    if v14:isA("TextButton") then
        local v_u_15 = v14:GetAttribute("name")
        if v_u_15 then
            v14.Activated:Connect(function(_, _)
                -- upvalues: (copy) v_u_15
                _E6_9B_B4_E6_94_B9_E8_AE_BE_E7_BD_AE(v_u_15)
            end)
            _E8_AE_BE_E7_BD_AE_E6_8C_89_E9_92_AE_E5_AF_B9_E8_B1_A1_E5_88_97_E8_A1_A8[v_u_15] = v14
        end
    end
end
local v16 = game:GetService("ReplicatedStorage")
local v17 = require((v16:WaitForChild("\232\132\154\230\156\172\230\168\161\229\157\151", 5):WaitForChild("\229\133\172\231\148\168", 5):WaitForChild("\229\188\149\231\148\168\231\174\161\231\144\134\229\153\168", 5)))
_E5_90_8C_E6_AD_A5_E8_AE_BE_E7_BD_AE_E6_95_B0_E6_8D_AE_E4_BA_8B_E4_BB_B6 = v17["\232\142\183\229\143\150\228\186\139\228\187\182\229\188\149\231\148\168"]("\232\174\190\231\189\174", "\229\144\140\230\173\165\232\174\190\231\189\174\230\149\176\230\141\174")
_E7_8E_A9_E5_AE_B6_E4_BF_AE_E6_94_B9_E8_AE_BE_E7_BD_AE_E4_BA_8B_E4_BB_B6 = v17["\232\142\183\229\143\150\228\186\139\228\187\182\229\188\149\231\148\168"]("\232\174\190\231\189\174", "\231\142\169\229\174\182\228\191\174\230\148\185\232\174\190\231\189\174")
UI_E5_8A_A8_E7_94_BB_E7_AE_A1_E7_90_86_E5_99_A8 = v17["\232\142\183\229\143\150\230\168\161\229\157\151\229\188\149\231\148\168"]("UI\229\138\168\231\148\187\231\174\161\231\144\134\229\153\168")
_E6_89_93_E5_BC_80_E8_AE_BE_E7_BD_AE_E4_BA_8B_E4_BB_B6 = v17["\232\142\183\229\143\150\228\186\139\228\187\182\229\188\149\231\148\168"]("\229\174\162\230\136\183\231\171\175UI", "\230\137\147\229\188\128\232\174\190\231\189\174")
_E6_89_93_E5_BC_80_E6_BF_80_E6_B4_BB_E7_A0_81_E4_BA_8B_E4_BB_B6 = v17["\232\142\183\229\143\150\228\186\139\228\187\182\229\188\149\231\148\168"]("\229\174\162\230\136\183\231\171\175UI", "\230\137\147\229\188\128\230\191\128\230\180\187\231\160\129")
_E6_89_93_E5_BC_80_E5_B8_88_E5_BE_92_E4_BA_8B_E4_BB_B6 = v17["\232\142\183\229\143\150\228\186\139\228\187\182\229\188\149\231\148\168"]("\229\174\162\230\136\183\231\171\175UI", "\230\137\147\229\188\128\229\184\136\229\190\146")
_E5_B8_B8_E9_87_8F = v17["\232\142\183\229\143\150\230\168\161\229\157\151\229\188\149\231\148\168"]("\229\184\184\233\135\143")
_E5_BC_B9_E5_87_BA_E6_A1_86_E6_98_BE_E7_A4_BA_E4_BA_8B_E4_BB_B6 = v17["\232\142\183\229\143\150\228\186\139\228\187\182\229\188\149\231\148\168"]("\229\174\162\230\136\183\231\171\175UI", "\230\137\147\229\188\128\229\188\185\229\135\186\230\161\134")
_E6_98_BE_E7_A4_BA_E6_96_87_E5_AD_97_E6_8F_90_E7_A4_BA_E4_BA_8B_E4_BB_B6 = v17["\232\142\183\229\143\150\228\186\139\228\187\182\229\188\149\231\148\168"]("\229\174\162\230\136\183\231\171\175UI", "\230\152\190\231\164\186\230\150\135\229\173\151\230\143\144\231\164\186")
_E6_97_B6_E9_97_B4_E6_A8_A1_E5_9D_97 = v17["\232\142\183\229\143\150\230\168\161\229\157\151\229\188\149\231\148\168"]("\230\151\182\233\151\180\230\168\161\229\157\151")
_E5_9B_9E_E5_9F_8E_E4_BA_8B_E4_BB_B6 = v17["\232\142\183\229\143\150\228\186\139\228\187\182\229\188\149\231\148\168"]("\228\188\160\233\128\129", "\229\155\158\229\159\142")
if _E5_B8_B8_E9_87_8F["\229\156\186\230\153\175\231\177\187\229\158\139"] == "\228\184\187\229\159\142" then
    _E5_9B_9E_E5_9F_8E_E6_8C_89_E9_92_AE_E6_A1_86_E6_9E_B6.Visible = false
end
event_customEvent_onFire_1 = _E6_89_93_E5_BC_80_E8_AE_BE_E7_BD_AE_E4_BA_8B_E4_BB_B6.Event:Connect(function(_, _, _)
    UI_E5_8A_A8_E7_94_BB_E7_AE_A1_E7_90_86_E5_99_A8["\230\152\190\231\164\186\229\138\168\231\148\187"](_E8_83_8C_E6_99_AF)
    UI_E5_8A_A8_E7_94_BB_E7_AE_A1_E7_90_86_E5_99_A8["\230\152\190\231\164\186\229\138\168\231\148\187"](_E4_B8_BB_E7_95_8C_E9_9D_A2, 0.05, 3)
    _E4_B8_BB_E7_95_8C_E9_9D_A2.Visible = true
end)
event_gui_Button_activated_2 = _E5_9B_9E_E5_9F_8E_E6_8C_89_E9_92_AE.Activated:Connect(function(_, _)
    _E5_9B_9E_E5_9F_8E_E4_BA_8B_E4_BB_B6:FireServer(nil)
    _E6_98_BE_E7_A4_BA_E6_96_87_E5_AD_97_E6_8F_90_E7_A4_BA_E4_BA_8B_E4_BB_B6:Fire("Teleporting...")
end)
event_gui_Button_activated_3 = _E5_85_B3_E9_97_AD_E6_8C_89_E9_92_AE.Activated:Connect(function(_, _)
    UI_E5_8A_A8_E7_94_BB_E7_AE_A1_E7_90_86_E5_99_A8["\229\133\179\233\151\173\229\138\168\231\148\187"](_E8_83_8C_E6_99_AF, nil, nil, _E5_85_B3_E9_97_AD_E5_9B_9E_E8_B0_83_E4_BA_8B_E4_BB_B6)
end)
event_customEvent_onFire_4 = _E5_85_B3_E9_97_AD_E5_9B_9E_E8_B0_83_E4_BA_8B_E4_BB_B6.Event:Connect(function(_, _, _)
    _E4_B8_BB_E7_95_8C_E9_9D_A2.Visible = false
end)
event_customEvent_onClientEvent_5 = _E5_90_8C_E6_AD_A5_E8_AE_BE_E7_BD_AE_E6_95_B0_E6_8D_AE_E4_BA_8B_E4_BB_B6.OnClientEvent:Connect(function(p18, _, _)
    _E7_8E_A9_E5_AE_B6_E8_AE_BE_E7_BD_AE_E6_95_B0_E6_8D_AE = p18
    _E6_9B_B4_E6_96_B0_E6_98_BE_E7_A4_BA()
end)
event_gui_Button_activated_6 = _E6_BF_80_E6_B4_BB_E7_A0_81_E6_8C_89_E9_92_AE.Activated:Connect(function(_, _)
    _E6_89_93_E5_BC_80_E6_BF_80_E6_B4_BB_E7_A0_81_E4_BA_8B_E4_BB_B6:Fire(nil)
end)
return _E8_AE_BE_E7_BD_AEUI_E7_AE_A1_E7_90_86_E5_99_A8