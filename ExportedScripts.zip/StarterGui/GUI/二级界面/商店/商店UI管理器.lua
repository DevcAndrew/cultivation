-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled with Velocity Script Decompiler
local v1 = game:GetService("CollectionService")
_E5_95_86_E5_BA_97UI_E7_AE_A1_E7_90_86_E5_99_A8 = {}
_E5_BC_95_E7_94_A8_E7_AE_A1_E7_90_86_E5_99_A8 = {}
UI_E5_8A_A8_E7_94_BB_E7_AE_A1_E7_90_86_E5_99_A8 = {}
_E5_8A_9F_E8_83_BD_E8_A7_A3_E9_94_81_E5_B7_A5_E5_85_B7 = {}
local v2 = require((game:GetService("ReplicatedStorage"):WaitForChild("BaseState", 60)))
require((game:GetService("ReplicatedStorage"):WaitForChild("FsmMachine", 60)))
local v3 = v2:New("\233\187\152\232\174\164\231\138\182\230\128\129")
function _E8_B7_B3_E8_BD_AC_E5_95_86_E5_BA_97(p4)
    _E6_89_93_E5_BC_80_E5_95_86_E5_BA_97(nil)
    _E5_88_87_E6_8D_A2_E7_95_8C_E9_9D_A2(p4)
end
function _E5_88_87_E6_8D_A2_E7_95_8C_E9_9D_A2(p5)
    local v6 = _E5_8A_9F_E8_83_BD_E8_A7_A3_E9_94_81_E5_B7_A5_E5_85_B7["\230\152\175\229\144\166\232\167\163\233\148\129"](p5)
    if v6 == nil or v6 then
        if _E4_B8_BB_E7_95_8C_E9_9D_A2.Visible then
            if p5 == "\229\143\172\229\148\164" then
                _E6_98_BE_E7_A4_BA_E8_B4_A7_E5_B8_81_E4_BA_8B_E4_BB_B6:Fire({ "\233\146\187\231\159\179", "\230\179\149\229\174\157\230\138\189\229\165\150\229\136\184", "\230\138\128\232\131\189\230\138\189\229\165\150\229\136\184" })
            else
                _E6_98_BE_E7_A4_BA_E8_B4_A7_E5_B8_81_E4_BA_8B_E4_BB_B6:Fire(nil)
            end
        end
        _E5_8E_9F_E6_A0_87_E7_AD_BE = p5
        local v7 = _E8_8F_9C_E5_8D_95_E6_A0_8F_E6_8C_89_E9_92_AE_E5_AD_97_E5_85_B8[p5]
        if _E5_8F_B3_E4_BE_A7_E7_95_8C_E9_9D_A2_E5_AD_97_E5_85_B8[p5] then
            if _E5_BD_93_E5_89_8D_E9_80_89_E4_B8_AD_E7_95_8C_E9_9D_A2 then
                _E5_BD_93_E5_89_8D_E9_80_89_E4_B8_AD_E7_95_8C_E9_9D_A2.Visible = false
            end
            _E5_BD_93_E5_89_8D_E9_80_89_E4_B8_AD_E7_95_8C_E9_9D_A2 = _E5_8F_B3_E4_BE_A7_E7_95_8C_E9_9D_A2_E5_AD_97_E5_85_B8[p5]
            _E5_BD_93_E5_89_8D_E9_80_89_E4_B8_AD_E7_95_8C_E9_9D_A2.Visible = true
            if _E5_BD_93_E5_89_8D_E9_80_89_E4_B8_AD_E8_8F_9C_E5_8D_95_E6_8C_89_E9_92_AE then
                _E5_BD_93_E5_89_8D_E9_80_89_E4_B8_AD_E8_8F_9C_E5_8D_95_E6_8C_89_E9_92_AE:FindFirstChild("UIStroke", false).Enabled = false
            end
            _E5_BD_93_E5_89_8D_E9_80_89_E4_B8_AD_E8_8F_9C_E5_8D_95_E6_8C_89_E9_92_AE = v7
            _E5_BD_93_E5_89_8D_E9_80_89_E4_B8_AD_E8_8F_9C_E5_8D_95_E6_8C_89_E9_92_AE:FindFirstChild("UIStroke", false).Enabled = true
            return
        end
    else
        local v8 = _E5_8A_9F_E8_83_BD_E8_A7_A3_E9_94_81_E8_A1_A8[p5]
        _E5_8A_9F_E8_83_BD_E8_A7_A3_E9_94_81_E5_B7_A5_E5_85_B7["\232\167\163\233\148\129\230\143\144\231\164\186"](v8["\228\184\150\231\149\140"], v8["\232\191\155\229\186\166"])
    end
end
function _E6_9B_B4_E6_96_B0_E8_A7_A3_E9_94_81UI(_)
    for v9, v10 in pairs(_E8_8F_9C_E5_8D_95_E6_A0_8F_E6_8C_89_E9_92_AE_E5_AD_97_E5_85_B8) do
        local _ = _E5_8A_9F_E8_83_BD_E8_A7_A3_E9_94_81_E8_A1_A8[v9]
        local v11 = _E5_8A_9F_E8_83_BD_E8_A7_A3_E9_94_81_E5_B7_A5_E5_85_B7["\230\152\175\229\144\166\232\167\163\233\148\129"](v9)
        if v11 ~= nil and v11 then
            local v12 = v10:FindFirstChild("\228\184\138\233\148\129", false)
            if v12.Visible then
                v10.BackgroundColor3 = Color3.fromRGB(208, 200, 175)
                v12.Visible = false
                local v13 = v10:FindFirstChild("\229\144\141\231\167\176", false)
                v13.TextColor3 = Color3.fromRGB(104, 81, 0)
                v13.Position = UDim2.new(0.5, 0, 0.5, 0)
            end
        end
    end
end
function _E6_89_93_E5_BC_80_E5_95_86_E5_BA_97(p14)
    if not _E4_B8_BB_E7_95_8C_E9_9D_A2.Visible then
        UI_E5_8A_A8_E7_94_BB_E7_AE_A1_E7_90_86_E5_99_A8["\230\152\190\231\164\186\229\138\168\231\148\187"](_E8_83_8C_E6_99_AF)
        UI_E5_8A_A8_E7_94_BB_E7_AE_A1_E7_90_86_E5_99_A8["\230\152\190\231\164\186\229\138\168\231\148\187"](_E4_B8_BB_E7_95_8C_E9_9D_A2, 0.05, 3)
        _E4_B8_BB_E7_95_8C_E9_9D_A2.Visible = true
        if _E5_8E_9F_E6_A0_87_E7_AD_BE == "\229\143\172\229\148\164" then
            _E6_98_BE_E7_A4_BA_E8_B4_A7_E5_B8_81_E4_BA_8B_E4_BB_B6:Fire({ "\233\146\187\231\159\179", "\230\179\149\229\174\157\230\138\189\229\165\150\229\136\184", "\230\138\128\232\131\189\230\138\189\229\165\150\229\136\184" })
        end
        if p14 then
            _E5_88_87_E6_8D_A2_E7_95_8C_E9_9D_A2(p14)
        end
    end
end
function v3.OnEnter(_) end
function v3.OnUpdate(_) end
function v3.OnLeave(_)
    event_customEvent_onFire_1:Disconnect()
    event_gui_Button_activated_2:Disconnect()
    event_customEvent_onFire_3:Disconnect()
    event_customEvent_onFire_4:Disconnect()
end
_E5_85_B3_E9_97_AD_E5_9B_9E_E8_B0_83_E4_BA_8B_E4_BB_B6 = Instance.new("BindableEvent")
_E4_B8_BB_E7_95_8C_E9_9D_A2 = script.Parent
_E8_83_8C_E6_99_AF = _E4_B8_BB_E7_95_8C_E9_9D_A2:WaitForChild("\232\131\140\230\153\175", 5)
_E5_85_B3_E9_97_AD_E6_8C_89_E9_92_AE = _E8_83_8C_E6_99_AF:WaitForChild("\229\133\179\233\151\173\230\140\137\233\146\174", 5):WaitForChild("\230\140\137\233\146\174", 5)
_E5_8F_B3_E4_BE_A7_E7_95_8C_E9_9D_A2_E5_AD_97_E5_85_B8 = {}
local v15 = _E8_83_8C_E6_99_AF:WaitForChild("\229\143\179\228\190\167\231\149\140\233\157\162", 5)
for _, v16 in ipairs(v15:GetChildren()) do
    v16.Visible = false
    _E5_8F_B3_E4_BE_A7_E7_95_8C_E9_9D_A2_E5_AD_97_E5_85_B8[v16.Name] = v16
end
_E8_8F_9C_E5_8D_95_E6_A0_8F = _E8_83_8C_E6_99_AF:WaitForChild("\232\143\156\229\141\149\230\160\143", 5)
_E8_8F_9C_E5_8D_95_E6_A0_8F_E6_8C_89_E9_92_AE_E5_AD_97_E5_85_B8 = {}
for _, v17 in ipairs(_E8_8F_9C_E5_8D_95_E6_A0_8F:GetDescendants()) do
    if v17:isA("TextButton") then
        local v_u_18 = v17.Parent.Name
        v17.Activated:Connect(function(_, _)
            -- upvalues: (copy) v_u_18
            _E5_88_87_E6_8D_A2_E7_95_8C_E9_9D_A2(v_u_18)
        end)
        _E8_8F_9C_E5_8D_95_E6_A0_8F_E6_8C_89_E9_92_AE_E5_AD_97_E5_85_B8[v_u_18] = v17
    end
end
_E7_BE_BD_E6_A0_B8_E6_A0_87_E7_AD_BE = _E8_8F_9C_E5_8D_95_E6_A0_8F:WaitForChild("\231\190\189\230\160\184", 5)
_E6_97_B6_E5_85_89_E5_95_86_E5_BA_97_E6_A0_87_E7_AD_BE = _E8_8F_9C_E5_8D_95_E6_A0_8F:WaitForChild("\230\151\182\229\133\137\229\149\134\229\186\151", 5)
_E8_B7_B3_E8_BD_AC_E5_95_86_E5_BA_97_E6_8C_89_E9_92_AE_E5_AD_97_E5_85_B8 = {}
for _, v19 in ipairs(v1:GetTagged("UI_\232\183\179\232\189\172\229\149\134\229\186\151")) do
    if not v19:FindFirstAncestorWhichIsA("StarterGui") then
        local v_u_20 = v19:GetAttribute("name")
        v19.Activated:Connect(function(_, _)
            -- upvalues: (copy) v_u_20
            _E8_B7_B3_E8_BD_AC_E5_95_86_E5_BA_97(v_u_20)
        end)
    end
end
local v21 = game:GetService("ReplicatedStorage")
_E5_BC_95_E7_94_A8_E7_AE_A1_E7_90_86_E5_99_A8 = require((v21:WaitForChild("\232\132\154\230\156\172\230\168\161\229\157\151", 5):WaitForChild("\229\133\172\231\148\168", 5):WaitForChild("\229\188\149\231\148\168\231\174\161\231\144\134\229\153\168", 5)))
_E6_89_93_E5_BC_80_E5_95_86_E5_BA_97_E4_BA_8B_E4_BB_B6 = _E5_BC_95_E7_94_A8_E7_AE_A1_E7_90_86_E5_99_A8["\232\142\183\229\143\150\228\186\139\228\187\182\229\188\149\231\148\168"]("\229\174\162\230\136\183\231\171\175UI", "\230\137\147\229\188\128\229\149\134\229\186\151")
UI_E5_8A_A8_E7_94_BB_E7_AE_A1_E7_90_86_E5_99_A8 = _E5_BC_95_E7_94_A8_E7_AE_A1_E7_90_86_E5_99_A8["\232\142\183\229\143\150\230\168\161\229\157\151\229\188\149\231\148\168"]("UI\229\138\168\231\148\187\231\174\161\231\144\134\229\153\168")
_E6_95_B0_E5_AD_A6_E8_BF_90_E7_AE_97 = _E5_BC_95_E7_94_A8_E7_AE_A1_E7_90_86_E5_99_A8["\232\142\183\229\143\150\230\168\161\229\157\151\229\188\149\231\148\168"]("\230\149\176\229\173\166\232\191\144\231\174\151")
_E6_97_B6_E9_97_B4_E6_A8_A1_E5_9D_97 = _E5_BC_95_E7_94_A8_E7_AE_A1_E7_90_86_E5_99_A8["\232\142\183\229\143\150\230\168\161\229\157\151\229\188\149\231\148\168"]("\230\151\182\233\151\180\230\168\161\229\157\151")
_E6_9B_B4_E6_96_B0_E9_80_81_E7_A4_BC_E7_9B_AE_E6_A0_87_E4_BA_8B_E4_BB_B6 = _E5_BC_95_E7_94_A8_E7_AE_A1_E7_90_86_E5_99_A8["\232\142\183\229\143\150\228\186\139\228\187\182\229\188\149\231\148\168"]("\229\149\134\229\186\151", "\230\155\180\230\150\176\233\128\129\231\164\188\231\155\174\230\160\135\228\186\139\228\187\182")
_E7_8E_A9_E5_AE_B6_E5_80_BC_E5_AF_B9_E8_B1_A1_E8_8E_B7_E5_8F_96_E5_AE_8C_E6_88_90_E4_BA_8B_E4_BB_B6 = _E5_BC_95_E7_94_A8_E7_AE_A1_E7_90_86_E5_99_A8["\232\142\183\229\143\150\228\186\139\228\187\182\229\188\149\231\148\168"]("\229\174\162\230\136\183\231\171\175\229\136\157\229\167\139\229\140\150", "\231\142\169\229\174\182\229\128\188\229\175\185\232\177\161\232\142\183\229\143\150\229\174\140\230\136\144")
_E5_8A_9F_E8_83_BD_E8_A7_A3_E9_94_81_E8_A1_A8 = _E5_BC_95_E7_94_A8_E7_AE_A1_E7_90_86_E5_99_A8["\232\142\183\229\143\150\230\149\176\230\141\174\232\161\168"]("\229\138\159\232\131\189\232\167\163\233\148\129\232\161\168")
_E5_8A_9F_E8_83_BD_E8_A7_A3_E9_94_81_E5_B7_A5_E5_85_B7 = _E5_BC_95_E7_94_A8_E7_AE_A1_E7_90_86_E5_99_A8["\232\142\183\229\143\150\230\168\161\229\157\151\229\188\149\231\148\168"]("\229\138\159\232\131\189\232\167\163\233\148\129\229\183\165\229\133\183")
_E5_90_8C_E6_AD_A5_E9_B2_B8_E9_B1_BC_E4_BA_8B_E4_BB_B6 = _E5_BC_95_E7_94_A8_E7_AE_A1_E7_90_86_E5_99_A8["\232\142\183\229\143\150\228\186\139\228\187\182\229\188\149\231\148\168"]("\229\149\134\229\186\151", "\229\144\140\230\173\165\233\178\184\233\177\188")
_E6_98_BE_E7_A4_BA_E8_B4_A7_E5_B8_81_E4_BA_8B_E4_BB_B6 = _E5_BC_95_E7_94_A8_E7_AE_A1_E7_90_86_E5_99_A8["\232\142\183\229\143\150\228\186\139\228\187\182\229\188\149\231\148\168"]("\229\174\162\230\136\183\231\171\175UI", "\230\152\190\231\164\186\232\180\167\229\184\129")
_E6_98_BE_E7_A4_BA_E6_96_87_E5_AD_97_E6_8F_90_E7_A4_BA_E4_BA_8B_E4_BB_B6 = _E5_BC_95_E7_94_A8_E7_AE_A1_E7_90_86_E5_99_A8["\232\142\183\229\143\150\228\186\139\228\187\182\229\188\149\231\148\168"]("\229\174\162\230\136\183\231\171\175UI", "\230\152\190\231\164\186\230\150\135\229\173\151\230\143\144\231\164\186")
_E5_88_87_E6_8D_A2_E7_95_8C_E9_9D_A2("\229\143\172\229\148\164")
event_customEvent_onFire_1 = _E7_8E_A9_E5_AE_B6_E5_80_BC_E5_AF_B9_E8_B1_A1_E8_8E_B7_E5_8F_96_E5_AE_8C_E6_88_90_E4_BA_8B_E4_BB_B6.Event:Connect(function(_, _, _)
    local v22 = _E5_BC_95_E7_94_A8_E7_AE_A1_E7_90_86_E5_99_A8["\232\142\183\229\143\150\231\142\169\229\174\182\229\128\188\229\175\185\232\177\161"]("\228\184\187\231\186\191\232\191\155\229\186\166", "\229\133\179\229\141\161")
    _E6_9B_B4_E6_96_B0_E8_A7_A3_E9_94_81UI(true)
    v22.Changed:Connect(function(_)
        _E6_9B_B4_E6_96_B0_E8_A7_A3_E9_94_81UI(true)
    end)
    if _E5_BC_95_E7_94_A8_E7_AE_A1_E7_90_86_E5_99_A8["\232\142\183\229\143\150\231\142\169\229\174\182\229\128\188\229\175\185\232\177\161\229\128\188"]("\228\191\161\230\129\175", "\231\173\137\231\186\167") >= 100 then
        _E7_BE_BD_E6_A0_B8_E6_A0_87_E7_AD_BE.Visible = true
    else
        _E7_BE_BD_E6_A0_B8_E6_A0_87_E7_AD_BE.Visible = false
    end
end)
event_gui_Button_activated_2 = _E5_85_B3_E9_97_AD_E6_8C_89_E9_92_AE.Activated:Connect(function(_, _)
    UI_E5_8A_A8_E7_94_BB_E7_AE_A1_E7_90_86_E5_99_A8["\229\133\179\233\151\173\229\138\168\231\148\187"](_E8_83_8C_E6_99_AF, nil, nil, _E5_85_B3_E9_97_AD_E5_9B_9E_E8_B0_83_E4_BA_8B_E4_BB_B6)
    _E6_98_BE_E7_A4_BA_E8_B4_A7_E5_B8_81_E4_BA_8B_E4_BB_B6:Fire(nil)
end)
event_customEvent_onFire_3 = _E6_89_93_E5_BC_80_E5_95_86_E5_BA_97_E4_BA_8B_E4_BB_B6.Event:Connect(function(p23, _, _)
    _E6_89_93_E5_BC_80_E5_95_86_E5_BA_97(p23)
end)
event_customEvent_onFire_4 = _E5_85_B3_E9_97_AD_E5_9B_9E_E8_B0_83_E4_BA_8B_E4_BB_B6.Event:Connect(function(_, _, _)
    _E4_B8_BB_E7_95_8C_E9_9D_A2.Visible = false
end)
return _E5_95_86_E5_BA_97UI_E7_AE_A1_E7_90_86_E5_99_A8