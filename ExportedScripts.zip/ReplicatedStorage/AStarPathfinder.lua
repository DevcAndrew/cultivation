-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled with Velocity Script Decompiler
local v_u_1 = {}
local v_u_2 = require(script:WaitForChild("AStarNode", 5))
function v_u_1.Init(p3, p4)
    -- upvalues: (copy) v_u_1, (copy) v_u_2
    local v5 = v_u_1
    local v6 = setmetatable({}, v5)
    v6.Rows = p3
    v6.Cols = p4
    v6.Grid = {}
    v6.OpenSet = {}
    v6.ClosedSet = {}
    v6.Path = {}
    for v7 = 1, v6.Rows do
        v6.Grid[v7] = {}
        for v8 = 1, v6.Cols do
            v6.Grid[v7][v8] = v_u_2.New(v7, v8)
        end
    end
    for v9 = 1, v6.Rows do
        for v10 = 1, v6.Cols do
            v6.Grid[v9][v10]:AddNeighbors(v6.Grid)
        end
    end
    function v6.SetWall(p11, p12, p13, p14)
        if p11.Rows >= p12 and p11.Cols >= p13 then
            p11.Grid[p12][p13].Wall = p14
        end
    end
    return v6
end
local function v_u_18(p15, p16)
    for v17 = 1, #p15 do
        if p15[v17] == p16 then
            table.remove(p15, v17)
            return
        end
    end
end
local function v_u_25(p19)
    -- upvalues: (copy) v_u_2
    local v20 = {}
    for v21 = 1, p19.Rows do
        v20[v21] = {}
        for v22 = 1, p19.Cols do
            v20[v21][v22] = v_u_2.New(v21, v22)
        end
    end
    for v23 = 1, p19.Rows do
        for v24 = 1, p19.Cols do
            v20[v23][v24]:AddNeighbors(v20)
            v20[v23][v24].Wall = p19.Grid[v23][v24].Wall
        end
    end
    p19.Grid = v20
end
function v_u_1.CalculationPath(p26, p27, p28)
    -- upvalues: (copy) v_u_25, (copy) v_u_18
    local v29 = p26.Grid[p27.x][p27.y]
    local v30 = p26.Grid[p28.x][p28.y]
    p26.Path = {}
    p26.OpenSet = {}
    p26.ClosedSet = {}
    v_u_25(p26)
    local v31 = p26.OpenSet
    table.insert(v31, v29)
    while true do
        if #p26.OpenSet <= 0 then
            local v32 = {}
            for v33 = 1, #p26.Path do
                v32[#p26.Path - v33 + 1] = Vector2.new(p26.Path[v33].x, p26.Path[v33].y)
            end
            return v32
        end
        if #p26.OpenSet > 0 then
            local v34 = 1
            for v35 = 1, #p26.OpenSet do
                if p26.OpenSet[v35].f < p26.OpenSet[v34].f then
                    v34 = v35
                end
            end
            local v36 = p26.OpenSet[v34]
            if v36 == v30 then
                p26.Path = {}
                local v37 = p26.Path
                table.insert(v37, v36)
                local v38 = 1
                while v36.previous do
                    v38 = v38 + 1
                    local v39 = p26.Path
                    local v40 = v36.previous
                    table.insert(v39, v40)
                    v36 = v36.previous
                end
                break
            end
            v_u_18(p26.OpenSet, v36)
            local v41 = p26.ClosedSet
            table.insert(v41, v36)
            local v42 = v36.neighbors
            local v43 = {}
            for _, v44 in ipairs(v42) do
                if v44 then
                    local v45 = p26.ClosedSet
                    for v46 = 1, #v45 do
                        if v45[v46] == v44 then
                            v47 = true
                            ::l22::
                            v48 = not v47
                            if v48 then
                                v48 = not v44.Wall
                            end
                            goto l17
                        end
                    end
                    local v47 = false
                    goto l22
                end
                local v48 = v44
                ::l17::
                table.insert(v43, v48)
            end
            for v49 = 1, #v42 do
                local v50 = v42[v49]
                local v51 = false
                if v43[v49] then
                    local v52 = v49 == 5 and (v43[1] and v43[4]) and true or false
                    local v53 = v49 == 6 and (v43[2] and v43[4]) and true or v52
                    local v54 = v49 == 7 and (v43[1] and v43[3]) and true or v53
                    local v55 = v49 == 8 and (v43[2] and v43[3]) and true or v54
                    if v49 <= 4 or v55 then
                        local v56 = v36.g + 1
                        local v57 = p26.OpenSet
                        for v58 = 1, #v57 do
                            if v57[v58] == v50 then
                                v60 = true
                                ::l50::
                                if v60 then
                                    if v56 < v50.g then
                                        v50.g = v56
                                        v51 = true
                                    end
                                else
                                    v50.g = v56
                                    local v59 = p26.OpenSet
                                    table.insert(v59, v50)
                                    v51 = true
                                end
                                goto l27
                            end
                        end
                        local v60 = false
                        goto l50
                    end
                end
                ::l27::
                if v51 then
                    v50:Heuristic(v30)
                    v50.f = v50.g + v50.h
                    v50.previous = v36
                end
            end
        end
    end
end
return v_u_1