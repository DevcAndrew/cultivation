-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled with Velocity Script Decompiler
local v_u_1 = {}
v_u_1.__index = v_u_1
Random.new()
function v_u_1.New(p2, p3)
    -- upvalues: (copy) v_u_1
    local v4 = v_u_1
    local v5 = setmetatable({}, v4)
    v5.f = 0
    v5.g = 0
    v5.h = 0
    v5.x = p2
    v5.y = p3
    v5.neighbors = {}
    v5.Wall = false
    return v5
end
function v_u_1.AddNeighbors(p6, p7)
    if not p6.Wall then
        local v8 = p6.y
        local v9 = p6.x
        if v8 < #p7[1] then
            local v10 = p6.neighbors
            local v11 = p7[v9][v8 + 1]
            table.insert(v10, v11)
        else
            local v12 = p6.neighbors
            table.insert(v12, false)
        end
        if v8 > 1 then
            local v13 = p6.neighbors
            local v14 = p7[v9][v8 - 1]
            table.insert(v13, v14)
        else
            local v15 = p6.neighbors
            table.insert(v15, false)
        end
        if v9 < #p7 then
            local v16 = p6.neighbors
            local v17 = p7[v9 + 1][v8]
            table.insert(v16, v17)
        else
            local v18 = p6.neighbors
            table.insert(v18, false)
        end
        if v9 > 1 then
            local v19 = p6.neighbors
            local v20 = p7[v9 - 1][v8]
            table.insert(v19, v20)
        else
            local v21 = p6.neighbors
            table.insert(v21, false)
        end
        if v8 < #p7[1] and v9 > 1 then
            local v22 = p6.neighbors
            local v23 = p7[v9 - 1][v8 + 1]
            table.insert(v22, v23)
        else
            local v24 = p6.neighbors
            table.insert(v24, false)
        end
        if v8 > 1 and v9 > 1 then
            local v25 = p6.neighbors
            local v26 = p7[v9 - 1][v8 - 1]
            table.insert(v25, v26)
        else
            local v27 = p6.neighbors
            table.insert(v27, false)
        end
        if v8 < #p7[1] and v9 < #p7 then
            local v28 = p6.neighbors
            local v29 = p7[v9 + 1][v8 + 1]
            table.insert(v28, v29)
        else
            local v30 = p6.neighbors
            table.insert(v30, false)
        end
        if v8 > 1 and v9 < #p7 then
            local v31 = p6.neighbors
            local v32 = p7[v9 + 1][v8 - 1]
            table.insert(v31, v32)
            return
        end
        local v33 = p6.neighbors
        table.insert(v33, false)
    end
end
function v_u_1.Show(p34)
    if not p34.Instance then
        local v35 = Instance.new("Part")
        v35.BrickColor = BrickColor.White()
        v35.Anchored = true
        v35.TopSurface = Enum.SurfaceType.Smooth
        v35.BottomSurface = Enum.SurfaceType.Smooth
        v35.CFrame = CFrame.new(p34.x, 0, p34.y)
        v35.Parent = game.Workspace
        v35.Size = Vector3.new(1, 1, 1)
        if p34.Wall then
            v35.BrickColor = BrickColor.Black()
        end
        p34.Instance = v35
    end
end
function v_u_1.Heuristic(p36, p37)
    p36.h = (Vector2.new(p36.x, p36.y) - Vector2.new(p37.x, p37.y)).magnitude
end
function v_u_1.ShowOpen(p38)
    if p38.Instance then
        p38.Instance.BrickColor = BrickColor.Blue()
    end
end
function v_u_1.ShowNeighbors(p39)
    for v40 = 1, #p39.neighbors do
        if not p39.neighbors[v40].Wall then
            p39.neighbors[v40].Instance.BrickColor = BrickColor.new("Royal purple")
        end
    end
    p39.Instance.BrickColor = BrickColor.new("Bright orange")
end
function v_u_1.ShowClosed(p41)
    if p41.Instance then
        p41.Instance.BrickColor = BrickColor.Red()
    end
end
function v_u_1.ShowPath(p42)
    if p42.Instance then
        p42.Instance.BrickColor = BrickColor.Yellow()
    end
end
return v_u_1