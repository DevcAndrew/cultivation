-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled with Velocity Script Decompiler
return {
    ["New"] = function(p1)
        p1.__index = p1
        local v2 = setmetatable({}, p1)
        v2.states = {}
        v2.curState = nil
        return v2
    end,
    ["AddState"] = function(p3, p4)
        p3.states[p4.stateName] = p4
    end,
    ["AddInitState"] = function(p5, p6)
        p5.curState = p6
        p5.curState:OnEnter()
    end,
    ["Update"] = function(p7)
        p7.curState:OnUpdate()
    end,
    ["Switch"] = function(p8, p9)
        if p8.curState.stateName ~= p9 then
            p8.curState:OnLeave()
            p8.curState = p8.states[p9]
            p8.curState:OnEnter()
        end
    end
}