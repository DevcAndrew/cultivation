-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiled with Velocity Script Decompiler
return {
    ["New"] = function(p1, p2)
        p1.__index = p1
        local v3 = setmetatable({}, p1)
        v3.stateName = p2
        return v3
    end,
    ["OnEnter"] = function(_) end,
    ["OnUpdate"] = function(_) end,
    ["OnLeave"] = function(_) end
}